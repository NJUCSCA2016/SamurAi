package ui.panelsetting;

import main.SingletonClass;
import main.StaticButton;
import sounds.Sounds;

public class ButtonSound extends StaticButton{
	
	public ButtonSound(int x ,int y ){
		
		//四个框框的大小应该是相同的，并且Img也是相同的
		super(x, y, 0, 0, null);
		
	}
	
}
