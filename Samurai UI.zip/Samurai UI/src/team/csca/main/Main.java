package team.csca.main;

import team.csca.view.MainFrame;

/**
 * 整个游戏的入口
 * @author Water
 *
 */
public class Main {

	public static void main(String[] args) {
		new MainFrame().setVisible(true);
	}

}
