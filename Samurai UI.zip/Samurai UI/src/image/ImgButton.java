/**
 * Date : Apr 3, 2016 5:46:52 PM
 */
package image;

import java.awt.Image;

import javax.swing.ImageIcon;

/**
 * @author Alone
 * Written by YYM
 */
public class ImgButton {
	
	public static Image PLAY_1 = new ImageIcon("Image/Button/P1.png").getImage();
	
	public static Image PLAY_2 = new ImageIcon("Image/Button/P2.png").getImage();
	
	public static Image PLAY_3 = new ImageIcon("Image/Button/P3.png").getImage();
	
}
