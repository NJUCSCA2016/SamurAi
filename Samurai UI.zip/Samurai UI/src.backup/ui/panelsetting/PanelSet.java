package ui.panelsetting;

import java.awt.Graphics;

import javax.swing.JPanel;

public class PanelSet extends JPanel{

	
	public void paint(Graphics g){
		
	}
}
