package ui.panelgame;

public class ButtonGExit {

}
