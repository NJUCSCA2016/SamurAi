package ui.panelgame;

public class ButtonGSound {

}
