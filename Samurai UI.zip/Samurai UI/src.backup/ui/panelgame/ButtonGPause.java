package ui.panelgame;

public class ButtonGPause {

}
