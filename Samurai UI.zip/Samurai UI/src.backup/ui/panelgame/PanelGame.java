package ui.panelgame;

import java.awt.Graphics;

import javax.swing.JPanel;

public class PanelGame extends JPanel{

	
	public void paint(Graphics g){
		
	}
	
}
