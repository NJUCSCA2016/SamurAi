/**
 * Date : Apr 4, 2016 11:47:09 PM
 */
package ui.panelexample;

import java.awt.Graphics;

import javax.swing.JPanel;

/**
 * @author Alone
 * Written by YYM
 */
public class PanelExample extends JPanel{

	
	
	public void paint(Graphics g){
		
	}
	
}
