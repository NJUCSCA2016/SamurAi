package image;

public class ImgMouse {

}
