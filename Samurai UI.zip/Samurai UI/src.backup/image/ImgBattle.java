/**
 * Date : Apr 3, 2016 5:47:58 PM
 */
package image;

/**
 * @author Alone
 * Written by YYM
 */
public class ImgBattle {

}
