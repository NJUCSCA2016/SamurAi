/**
 * Date : Apr 3, 2016 5:51:06 PM
 */
package image;

/**
 * @author Alone
 * Written by YYM
 */
public class ImgString {
	
}
